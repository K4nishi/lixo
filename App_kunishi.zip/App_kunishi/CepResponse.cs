﻿namespace App_kunishi
{
    internal class CepResponse
    {
    }
}